from setuptools import setup
setup(name='smamp',
      version='1.04',
      description='Self-consistently optimizing smamp charges.',
      packages=['smamp'],
      url='',
      license='MIT',
      author='Lukas Elflein',
      author_email='elfleinl@tf.uni-freiburg.de'
     )
